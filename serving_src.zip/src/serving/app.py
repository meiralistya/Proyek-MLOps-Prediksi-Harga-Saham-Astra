from fastapi import FastAPI
from pydantic import BaseModel
import mlflow.pyfunc
import pandas as pd

app = FastAPI(title="ASII Stock Price Prediction API")

model = mlflow.pyfunc.load_model(model_uri="models:/ASII_Predictor/Production")

class StockInput(BaseModel):
    return_1d: float
    lag_1: float
    lag_3: float
    lag_5: float
    sma_5: float
    sma_10: float

@app.post("/predict")
def predict(data: StockInput):
    df = pd.DataFrame([data.dict()])
    prediction = model.predict(df)
    return {"predicted_close_price": float(prediction[0])}
